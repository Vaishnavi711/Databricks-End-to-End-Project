# Databricks notebook source
from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.window import Window

# COMMAND ----------

df = spark.read.format("parquet")\
        .load("abfss://bronze@databriproject.dfs.core.windows.net/orders")

# COMMAND ----------

df.display()

# COMMAND ----------

df.printSchema()

# COMMAND ----------

df=df.withColumnRenamed('_rescued_data','Rescued_Data').display()

# COMMAND ----------

#Drop_Column
df=df.drop('_rescued_data')
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Date Transformations**

# COMMAND ----------

df=df.withColumn('order_date',to_timestamp(col('order_date')))
df.display()

# COMMAND ----------

#couln by order date
df=df.withColumn('year',year(col('order_date')))
df.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Window Functions**

# COMMAND ----------

#dense Ranking by total_amount
df1=df.withColumn('flag', dense_rank().over(Window.partitionBy('year').orderBy(desc('total_amount'))))
df1.display()

# COMMAND ----------

#Ranking by total_amount
df1=df1.withColumn('rank_flag',rank().over(Window.partitionBy('year').orderBy(desc('total_amount'))))
df1.display()

# COMMAND ----------

df1=df1.withColumn('row_flag',row_number().over(Window.partitionBy('year').orderBy(desc('total_amount'))))
df1.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Classes OOP

# COMMAND ----------

class windows:

  def dense_rank(self,df):

    df_dense_rank = df.withColumn("flag",dense_rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))

    return df_dense_rank

  def rank(self,df):

    df_rank = df.withColumn("rank_flag",rank().over(Window.partitionBy("year").orderBy(desc("total_amount"))))

    return df_rank

  def row_number(self,df):  

    df_row_number = df.withColumn("row_flag",row_number().over(Window.partitionBy("year").orderBy(desc("total_amount"))))

    return df_row_number

# COMMAND ----------

df_new=df

# COMMAND ----------

df_new.display()

# COMMAND ----------

obj=windows()

# COMMAND ----------

df_res=obj.dense_rank(df_new)

# COMMAND ----------

df_res.display()

# COMMAND ----------

# MAGIC %md
# MAGIC ### **Data Writing**

# COMMAND ----------

df.write.format("delta").mode("overwrite").save("abfss://silver@databriproject.dfs.core.windows.net/orders")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS databricks_cata.silver.orders_silver
# MAGIC USING DELTA 
# MAGIC LOCATION 'abfss://silver@databriproject.dfs.core.windows.net/orders'